-- Extend this schema as needed
CREATE TABLE IF NOT EXISTS diseases (
    name TEXT PRIMARY KEY,
    symptoms TEXT,
    treatment TEXT
);
